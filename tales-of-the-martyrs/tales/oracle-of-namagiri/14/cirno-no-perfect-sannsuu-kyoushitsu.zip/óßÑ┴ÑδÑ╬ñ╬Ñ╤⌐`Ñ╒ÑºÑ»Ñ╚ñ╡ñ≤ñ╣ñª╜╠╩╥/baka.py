from Crypto.Util.number import *
from secret import flag    # What is `flag`?
from random import randrange
from decimal import Decimal, getcontext

assert flag.startswith(b'Spirit{') and flag.endswith(b'}')

pad = lambda m, l: m + bytes(randrange(256)*bool(i) for i in range(l - len(m)))
unpad = lambda m: m[:m.index(0)] if 0 in m else m

flag1 = flag[:len(flag)//3]
flag2 = flag[len(flag)//3:2*len(flag)//3]
flag3 = flag[2*len(flag)//3:]

flag1 = pad(flag1, 222)
flag2 = pad(flag2, 222)
flag3 = pad(flag3, 222)

flag1 = bytes_to_long(flag1)
flag2 = bytes_to_long(flag2)
flag3 = bytes_to_long(flag3)

e1 = 0x9999999999800001
d2 = 0x11451419198101
d3 = 0x1333333333333337

while 1:
    p1 = getPrime(1024)
    q1 = getPrime(1024)
    N1 = p1*q1
    phi1 = (p1-1)*(q1-1)
    if GCD(phi1, e1) == 1: break
c1 = pow(flag1, e1, N1)

while 1:
    p2 = getPrime(1024)
    q2 = getPrime(1024)
    N2 = p2*q2
    phi2 = (p2-1)*(q2-1)
    if GCD(phi2, d2) == 1: break
e2 = pow(d2, -1, phi2)
c2 = pow(flag2, e2, N2)

while 1:
    p3 = getPrime(1024)
    q3 = getPrime(1024)
    N3 = p3*q3
    phi3 = (p3-1)*(q3-1)
    if GCD(phi3, d3) == 1: break
e3 = pow(d3, -1, phi3)
c3 = pow(flag3, e3, N3)


f = open("output.txt", "w", encoding = "utf-8")

print("みんなー！", file = f)
print("チルノのさんすう教室はじまるよー！", file = f)
print(file = f)

print("Hey guys!", file = f)
print("Welcome to Cirno's math class!", file = f)
print(file = f)

print("大家好！", file = f)
print("琪露诺的算术课要开始了哦！", file = f)
print(file = f)


print("①！", file = f)

Q1_1 = (9*pow(p1, 411, N1)   + 19*pow(q1, 415, N1)) % N1
Q1_2 = (91*pow(p1, 9191, N1) + 9919*pow(q1, 398018, N1)) % N1

print(f"{Q1_1 = }", file = f)
print(f"{Q1_2 = }", file = f)
print(f"{c1 = }", file = f)
print(f"{N1 = }", file = f)
print(file = f)


print("②！", file = f)

getcontext().prec = 1145

a = Decimal(N2-10**615)/(N2+10**615)
b = Decimal(N2**2-2*10**615*N2+10**1230)/(N2**2+2*10**615*N2+10**1230)
c = 0
i = 1

for funky in 'あたいの足技、みさらせや！ ダンスのチャンスにパンクな乱舞で あんたのマウスはあんぐり「なんちゅうFunky☆」 ダンスにあんよの小指をガンつって ファンブルもやるけどあたいは「年中ダンス」'*199:
    c += a/i
    i += 2
    a *= b

c *= 2

Q2 = c

print(f"{Q2 = }", file = f)
print(f"{c2 = }", file = f)
print(file = f)


print("⑨！！！", file = f)

getcontext().prec = 4000

a = Decimal(N3)
b = Decimal(1)/40000
c = 0

for baka in 'bakabakabakabakabakabakabakabakabakabaka'*1000:
    c += Decimal(10**1860)/(a**3 + 1)
    a += b

c *= Decimal(1)/40000

Q3 = c

print(f"{Q3 = }", file = f)
print(f"{c3 = }", file = f)
print(file = f)


f.close()
