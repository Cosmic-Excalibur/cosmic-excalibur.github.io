from Crypto.Util.number import *
# pip install pycryptodome
import random

flag = input().encode('utf-8')    # What did I input here?
assert flag.startswith(b'Spirit{') and flag.endswith(b'}')
assert len(flag) < 100

flag = flag + bytes(random.randrange(256)*bool(i) for i in range(100 - len(flag)))    # pad to 100 bytes :D
m = int.from_bytes(flag, 'big')

e = 0x10001

while 1:
    p = getPrime(64)
    q = getPrime(64)
    r = getPrime(64)
    s = getPrime(80)
    t = getPrime(80)
    u = getPrime(80)
    v = getPrime(80)
    w = getPrime(80)
    x = getPrime(80)
    y = getPrime(81)
    z = getPrime(82)
    phi = (p-1)*(q-1)*(r-1)*(s-1)*(t-1)*(u-1)*(v-1)*(w-1)*(x-1)*(y-1)*(z-1)
    N = p*q*r*s*t*u*v*w*x*y*z
    if GCD(e, phi) == 1:
        break

cp = pow(m, e, p)
cq = pow(m, e, q)
cr = pow(m, e, r)
cs = pow(m, e, s)
ct = pow(m, e, t)
cu = pow(m, e, u)
cv = pow(m, e, v)
cw = pow(m, e, w)
cx = pow(m, e, x)
cy = pow(m, e, y)
cz = pow(m, e, z)

print(f"{cp = }")
print(f"{cq = }")
print(f"{cr = }")
print(f"{cs = }")
print(f"{ct = }")
print(f"{cu = }")
print(f"{cv = }")
print(f"{cw = }")
print(f"{cx = }")
print(f"{cy = }")
print(f"{cz = }")
print(f"{N = }")

'''
cp = 11950858997012813763
cq = 4520939618822401845
cr = 8844180690999831301
cs = 573109408139129907886906
ct = 320830844868480195117225
cu = 435943571295739879336853
cv = 102378072707962058317004
cw = 586395959972024480242744
cx = 298220611556138459858440
cy = 748490897011199405784845
cz = 555239577043963350083001
N = 3051894145074946964892081546739249165152388989030253479819705007225781583459323768663991828047787099597539247295629680743347713301236979959688225611140167007428308561703447209320872554838091406557091034728024674379556190264723842615740396416410356609
'''
